import React, { Component } from 'react';
//import logo from './logo.svg';

class Header extends Component {
    render() {
        return (
            <div className="Header">

                <img src="images/wired-brain-coffee-logo.png" alt="Wired Brain" />
            </div>
        );
    }
}

export default Header;